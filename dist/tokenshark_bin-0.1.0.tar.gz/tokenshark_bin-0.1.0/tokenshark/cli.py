def app():
    print('TokenShark CLI ready')
